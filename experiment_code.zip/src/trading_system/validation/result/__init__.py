"""
Result Validation Module
=======================

Minimal result validation - only what's actually used.
"""

from .experiment_result_validator import ExperimentResultValidator

__all__ = [
    'ExperimentResultValidator',
]
