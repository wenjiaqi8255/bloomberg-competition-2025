"""
Bloomberg Competition Trading System
A quantitative trading framework for team collaboration and experimentation.
"""

__version__ = "0.1.0"
__author__ = "Team"