# Strategy Module - Refactored Architecture

## 📐 Architecture Overview

This module implements a **component-based, dependency injection architecture** for trading strategies, following SOLID principles.

### Core Design Principles

1. **Dependency Injection**: Strategies receive all dependencies via constructor
2. **Single Responsibility**: Each component has one clear purpose
3. **Interface Segregation**: Abstract interfaces define contracts
4. **Composition over Inheritance**: Components are composed, not inherited

---

## 🏗️ Module Structure

```
strategies/
├── interfaces/           # Abstract interfaces (contracts)
│   ├── signal_generator_interface.py
│   ├── feature_provider_interface.py
│   └── risk_manager_interface.py
│
├── signal/              # Signal generation components
│   ├── ml_signal_generator.py
│   ├── factor_signal_generator.py
│   └── technical_signal_generator.py
│
├── utils/               # Utility components
│   └── portfolio_calculator.py
│
├── base_strategy.py     # Abstract base class
├── ml_strategy.py       # ML-based strategy
├── dual_momentum.py     # Dual momentum strategy
├── fama_french_5.py     # Fama-French 5-factor strategy
└── factory.py           # Strategy factory with auto-injection
```

---

## 🔧 Component Types

### 1. **ML Strategies** (e.g., MLStrategy)
**Dependencies:**
- `FeatureEngineeringPipeline` - Feature engineering pipeline (fitted to model)
- `ModelPredictor` - ML model for predictions
- `PositionSizer` - Risk management

**Usage:**
```python
from trading_system.feature_engineering.pipeline import FeatureEngineeringPipeline
from trading_system.models.serving.predictor import ModelPredictor
from trading_system.utils.position_sizer import PositionSizer

# 1. Create dependencies
# Load fitted pipeline from model or create new one
feature_pipeline = FeatureEngineeringPipeline.from_config(feature_config)
model_predictor = ModelPredictor(model_id="my_model_v1")
position_sizer = PositionSizer(volatility_target=0.15, max_position_weight=0.10)

# 2. Inject into strategy
strategy = MLStrategy(
    name="MyMLStrategy",
    model_predictor=model_predictor,
    feature_pipeline=feature_pipeline,
    position_sizer=position_sizer
)

# 3. Generate signals
signals = strategy.generate_signals(price_data, start_date, end_date)
```

### 2. **Factor Strategies** (e.g., DualMomentumStrategy, FamaFrench5Strategy)
**Dependencies:**
- `TechnicalIndicatorCalculator` - Specific factor calculations
- `PositionSizer` - Risk management

**Usage:**
```python
from trading_system.feature_engineering.utils.technical_features import TechnicalIndicatorCalculator
from trading_system.utils.position_sizer import PositionSizer

# 1. Create dependencies
technical_calculator = TechnicalIndicatorCalculator()
position_sizer = PositionSizer(volatility_target=0.15, max_position_weight=0.10)

# 2. Inject into strategy
strategy = DualMomentumStrategy(
    name="DualMomentum",
    technical_calculator=technical_calculator,
    position_sizer=position_sizer,
    lookback_period=252,
    top_n=5
)

# 3. Generate signals
signals = strategy.generate_signals(price_data, start_date, end_date)
```

---

## 🏭 Factory Pattern Usage

### Manual Creation
```python
from trading_system.strategies import StrategyFactory

# Register strategies (auto-called on import)
from trading_system.strategies import register_all_strategies
register_all_strategies()

# Create with manual dependency injection
strategy = StrategyFactory.create(
    'dual_momentum',
    name='DM_Strategy',
    technical_calculator=my_calculator,
    position_sizer=my_sizer,
    lookback_period=252
)
```

### Auto-Injection from Config
```python
from trading_system.strategies.factory import create_strategy_from_config

config = {
    'type': 'dual_momentum',
    'name': 'DM_Strategy',
    'lookback_period': 252,
    'top_n': 5,
    'position_sizing': {
        'volatility_target': 0.15,
        'max_position_weight': 0.10
    }
}

# Dependencies auto-created and injected
strategy = create_strategy_from_config(config)
```

---

## 📊 Available Strategies

| Strategy | Type | Dependencies | Description |
|----------|------|--------------|-------------|
| `MLStrategy` | ML | FeatureEngineeringPipeline, ModelPredictor, PositionSizer | Machine learning predictions |
| `DualMomentumStrategy` | Factor | TechnicalCalculator, PositionSizer | Absolute + relative momentum |
| `FamaFrench5Strategy` | Factor | TechnicalCalculator, PositionSizer | 5-factor model (MKT, SMB, HML, RMW, CMA) |

---

## 🔄 Signal Flow

```
Price Data
    ↓
[Feature Provider: FeatureEngineeringPipeline or TechnicalCalculator]
    ↓
Features/Factors
    ↓
[Signal Generator: Model or Factor Logic]
    ↓
Raw Signals
    ↓
[Risk Manager: PositionSizer]
    ↓
Final Portfolio Weights
```

---

## ✅ Best Practices

1. **Always use dependency injection** - Don't create dependencies inside strategies
2. **Use factory for consistency** - `create_strategy_from_config()` handles dependencies
3. **Keep strategies focused** - They should only orchestrate, not implement
4. **Reuse components** - FeatureEngineeringPipeline, TechnicalCalculator, PositionSizer are shared
5. **Follow interfaces** - Implement ISignalGenerator, IFeatureProvider, IRiskManager when creating new components
6. **Pipeline consistency** - ML strategies must use the same fitted pipeline used during training

---

## 🚀 Adding New Strategies

1. Create strategy class inheriting from `BaseStrategy`
2. Define required dependencies in `__init__`
3. Implement `generate_signals()` method
4. Register in `factory.py::register_all_strategies()`
5. Add config support in `create_strategy_from_config()`

Example:
```python
class MyNewStrategy(BaseStrategy):
    def __init__(self, name: str, 
                 my_dependency: MyDependency,
                 position_sizer: PositionSizer,
                 **kwargs):
        super().__init__(name, **kwargs)
        self.my_dependency = my_dependency
        self.position_sizer = position_sizer
    
    def generate_signals(self, price_data, start_date, end_date):
        # Implement logic using dependencies
        pass
```

---

## 📝 Notes

- Old `signal_generator.py` and `stock_selector.py` have been removed
- Old `factor_strategy.py` has been replaced by specific factor strategies
- All strategies now follow the same dependency injection pattern
- Factory supports both manual and automatic dependency creation
