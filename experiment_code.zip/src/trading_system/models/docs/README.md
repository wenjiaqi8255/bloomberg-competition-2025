# Trading System Models Module

## 概述
机器学习模型模块，负责训练、管理和部署各种量化交易模型。

## 主要组件

### 1. Base Model (`base/base_model.py`)
**类名**: `BaseModel`

**主要功能**:
- 所有模型的抽象基类
- 定义标准接口和生命周期管理
- 模型状态管理和元数据

**核心方法**:
```python
class BaseModel:
    def fit(self, X: pd.DataFrame, y: pd.Series) -> None
    def predict(self, X: pd.DataFrame) -> np.ndarray
    def save(self, path: str) -> None
    def load(self, path: str) -> None
    def get_model_info(self) -> Dict[str, Any]
```

### 2. FF5 Regression Model (`implementations/ff5_model.py`)
**类名**: `FF5RegressionModel` (不是测试中的 `FamaFrench5FactorModel`)

**主要功能**:
- Fama-French 5因子回归模型
- 因子beta估计
- 因子隐含收益率预测

**模型公式**:
```
R_stock = α + β_MKT * R_MKT + β_SMB * R_SMB + β_HML * R_HML +
          β_RMW * R_RMW + β_CMA * R_CMA + ε
```

**因子定义**:
- **MKT**: 市场超额收益
- **SMB**: Small Minus Big (规模因子)
- **HML**: High Minus Low (价值因子)
- **RMW**: Robust Minus Weak (盈利能力因子)
- **CMA**: Conservative Minus Aggressive (投资因子)

**使用示例**:
```python
from trading_system.models.implementations.ff5_model import FF5RegressionModel

model = FF5RegressionModel()
model.fit(factor_data, stock_returns)
predictions = model.predict(new_factor_data)
betas = model.get_factor_betas()
```

### 3. Residual Model (`implementations/residual_model.py`)
**类名**: `ResidualModel`

**主要功能**:
- 残差预测模型
- 基于FF5模型残差的预测
- 支持多种机器学习算法

### 4. Model Factory (`base/model_factory.py`)
**类名**: `ModelFactory`

**主要功能**:
- 模型创建和管理
- 支持配置驱动的模型实例化
- 模型注册和发现

### 5. Model Registry (`registry.py`)
**类名**: `ModelRegistry`

**主要功能**:
- 模型版本管理
- 模型持久化和加载
- 模型元数据管理

## 训练组件

### 1. Trainer (`training/trainer.py`)
**类名**: `ModelTrainer`

**主要功能**:
- 模型训练流程
- 交叉验证
- 性能评估

### 2. Hyperparameter Optimizer (`training/hyperparameter_optimizer.py`)
**类名**: `HyperparameterOptimizer`

**主要功能**:
- 超参数优化
- 使用Optuna进行贝叶斯优化
- 支持自定义搜索空间

### 3. Experiment Manager (`training/experiment_manager.py`)
**类名**: `TrainingExperimentManager`

**主要功能**:
- 训练实验管理
- 实验跟踪和比较
- 与WandB集成

### 4. Pipeline (`training/pipeline.py`)
**类名**: `TrainingPipeline`

**主要功能**:
- 端到端训练流程
- 数据预处理和特征工程
- 模型训练和评估

## 服务组件

### 1. Predictor (`serving/predictor.py`)
**类名**: `ModelPredictor`

**主要功能**:
- 模型预测服务
- 批量预测和实时预测
- 预测结果缓存

### 2. Monitor (`serving/monitor.py`)
**类名**: `ModelMonitor`

**主要功能**:
- 模型性能监控
- 模型漂移检测
- 预测质量评估

### 3. Dashboard (`serving/dashboard.py`)
**类名**: `ModelDashboard`

**主要功能**:
- 模型性能可视化
- 交互式仪表板
- 性能报告生成

## 工具组件

### 1. Performance Evaluator (`utils/performance_evaluator.py`)
**类名**: `PerformanceEvaluator`

**主要功能**:
- 模型性能评估
- 各种性能指标计算
- 基准比较

### 2. Model Persistence (`model_persistence.py`)
**类名**: `ModelPersistence`

**主要功能**:
- 模型序列化和反序列化
- 模型版本管理
- 存储和加载优化

## 数据结构

### 输入数据
- **特征数据**: `pd.DataFrame` - 包含所有特征
- **目标变量**: `pd.Series` - 预测目标
- **因子数据**: `pd.DataFrame` - Fama-French因子数据

### 输出数据
- **预测结果**: `np.ndarray` - 预测值
- **概率**: `np.ndarray` - 预测概率（分类问题）
- **特征重要性**: `Dict[str, float]` - 特征重要性分数

### 模型元数据
```python
@dataclass
class ModelMetadata:
    model_type: str
    version: str
    training_date: datetime
    performance_metrics: Dict[str, float]
    hyperparameters: Dict[str, Any]
    feature_names: List[str]
    model_size: int
```

## 配置示例

### 模型配置
```yaml
model:
  type: "ff5_regression"
  name: "ff5_model_v1"

  hyperparameters:
    alpha: 0.05
    fit_intercept: True
    normalize: True

  training:
    validation_split: 0.2
    cross_validation_folds: 5
    scoring_metric: "sharpe_ratio"
```

### 训练配置
```yaml
training:
  optimizer:
    n_trials: 100
    direction: "maximize"
    timeout: 3600

  experiment_tracking:
    wandb_project: "trading-models"
    log_model: True
    log_predictions: True
```

## 性能指标

### 回归指标
- **R²**: 决定系数
- **MSE**: 均方误差
- **MAE**: 平均绝对误差
- **Sharpe Ratio**: 夏普比率
- **Information Coefficient**: 信息系数

### 分类指标
- **Accuracy**: 准确率
- **Precision**: 精确率
- **Recall**: 召回率
- **F1-Score**: F1分数

## 依赖项
- `scikit-learn` - 机器学习库
- `xgboost` - 梯度提升
- `lightgbm` - 轻量级梯度提升
- `statsmodels` - 统计模型
- `optuna` - 超参数优化
- `wandb` - 实验跟踪

## 最佳实践
1. 总是使用交叉验证来评估模型性能
2. 记录所有实验参数和结果
3. 定期监控模型性能和漂移
4. 使用适当的正则化防止过拟合
5. 考虑特征重要性和可解释性