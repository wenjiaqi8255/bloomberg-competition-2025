"""
Data providers and market data acquisition modules.
"""