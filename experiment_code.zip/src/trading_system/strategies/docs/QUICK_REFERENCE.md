# Unified Strategy Architecture - Quick Reference

## 🚀 快速开始

### 1分钟创建策略

```python
from trading_system.strategies import create_strategy

# 创建双动量策略
strategy = create_strategy({
    'type': 'dual_momentum',
    'name': 'DM_252',
    'model_id': 'momentum_ranking_v1',
    'lookback_period': 252,
    'position_sizing': {
        'volatility_target': 0.15,
        'max_position_weight': 0.10
    }
})

# 生成信号
signals = strategy.generate_signals(price_data, start_date, end_date)
```

---

## 📋 可用策略类型

| 类型 | 配置type | Model需求 | 特征需求 |
|------|----------|-----------|----------|
| ML策略 | `'ml'` | ML模型 (RF, XGB, etc.) | 全量特征 |
| 双动量 | `'dual_momentum'` | MomentumRankingModel 🔨 | 动量特征 |
| FF5因子 | `'fama_french'` | FF5RegressionModel ✅ | 因子特征 |

✅ = 已存在  
🔨 = 需要实现（见TODO）

---

## 🔧 配置模板

### ML Strategy
```python
{
    'type': 'ml',
    'name': 'MLStrategy_RF',
    'model_id': 'random_forest_v1',
    'min_signal_strength': 0.1,
    'position_sizing': {
        'volatility_target': 0.15,
        'max_position_weight': 0.10
    }
}
```

### Dual Momentum
```python
{
    'type': 'dual_momentum',
    'name': 'DM_252',
    'model_id': 'momentum_ranking_v1',  # TODO: 需要实现
    'lookback_period': 252,
    'position_sizing': {
        'volatility_target': 0.15,
        'max_position_weight': 0.10
    }
}
```

### Fama-French 5
```python
{
    'type': 'fama_french',
    'name': 'FF5',
    'model_id': 'ff5_regression_v1',  # ✅ 已存在
    'lookback_days': 252,
    'risk_free_rate': 0.02,
    'position_sizing': {
        'volatility_target': 0.15,
        'max_position_weight': 0.10
    }
}
```

---

## 🏗️ 架构流程

```
1. FeatureEngineeringPipeline
   └─ 计算特征（动量、波动率、技术指标等）

2. ModelPredictor
   └─ 加载模型并预测

3. PositionSizer
   └─ 风险管理和仓位控制

4. 输出Signals
   └─ 最终的组合权重
```

---

## 📝 TODO清单

### 高优先级
- [ ] 实现 `MomentumRankingModel`
- [ ] 验证ML模型存在
- [ ] ModelPredictor支持model_id

### 中优先级
- [ ] 模型注册系统
- [ ] Pipeline预训练
- [ ] 集成测试

---

## 📚 文档

- `UNIFIED_ARCHITECTURE.md` - 完整架构文档
- `TODO_MODELS.md` - 模型实现TODO
- 代码注释 - 每个文件都有详细注释

---

## ✅ 核心理念

**所有策略 = Pipeline + Model + RiskManager**

区别只在于**使用什么特征和什么模型**，架构完全统一！

