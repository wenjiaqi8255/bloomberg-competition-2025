# TODO: Required Models for Unified Strategy Architecture

This document lists the models that need to be implemented to support
the unified strategy architecture.

---

## ✅ EXISTING MODELS

### 1. FF5RegressionModel
**File:** `ff5_model.py`  
**Status:** ✅ Already Implemented  
**Used By:** FamaFrench5Strategy

**Description:**
- Fama-French 5-factor regression model
- Estimates factor betas using linear regression
- Predicts expected returns based on factor exposures

**Features Expected:**
- MKT, SMB, HML, RMW, CMA factors

---

## 🔨 TODO: MODELS TO IMPLEMENT

### 2. MomentumRankingModel
**File:** `momentum_model.py` (TO BE CREATED)  
**Status:** 🔨 TODO  
**Used By:** DualMomentumStrategy

**Description:**
A model that implements dual momentum strategy logic:
- Absolute momentum: Filter for positive returns
- Relative momentum: Rank and select top N performers
- Can be rule-based or trained to optimize momentum weights

**Expected Interface:**
```python
class MomentumRankingModel(BaseModel):
    """
    Dual Momentum Model
    
    This model implements momentum-based ranking and selection.
    It can operate in two modes:
    1. Rule-based: Use fixed momentum ranking logic
    2. Trainable: Learn optimal momentum combination weights
    """
    
    def __init__(self, model_type="momentum_ranking", config=None):
        """
        Args:
            config:
                - mode: 'rule_based' or 'trainable'
                - top_n: Number of top performers to select
                - min_momentum: Minimum momentum threshold
                - momentum_periods: [21, 63, 252] momentum lookbacks
        """
        pass
    
    def fit(self, X, y):
        """
        Learn optimal momentum weights (if trainable).
        
        Args:
            X: Features with momentum_21d, momentum_63d, momentum_252d
            y: Forward returns
        """
        if self.config.get('mode') == 'trainable':
            # Learn linear combination weights
            # e.g., optimal_signal = w1*mom_21d + w2*mom_63d + w3*mom_252d
            pass
        # Rule-based mode: no training needed
        pass
    
    def predict(self, X):
        """
        Generate momentum-based signals.
        
        Returns:
            Expected returns or selection signals for top N assets
        """
        # 1. Calculate momentum score (composite or single period)
        # 2. Apply absolute momentum filter (>= min_momentum)
        # 3. Rank remaining assets
        # 4. Select top N
        # 5. Return signals (1.0 for selected, 0.0 for others)
        pass
```

**Features Expected:**
- `momentum_21d`: 21-day momentum
- `momentum_63d`: 63-day momentum  
- `momentum_252d`: 252-day momentum
- Optional: `volatility_*d` for risk-adjusted momentum

---

### 3. LinearFactorModel (OPTIONAL - Generalization)
**File:** `linear_factor_model.py` (TO BE CREATED)  
**Status:** 🔨 TODO (Lower Priority)  
**Used By:** Generic factor strategies

**Description:**
A general-purpose linear factor model that can be used for any
factor-based strategy. FF5Model is a specific instance of this.

**Expected Interface:**
```python
class LinearFactorModel(BaseModel):
    """
    Generic Linear Factor Model
    
    Models expected returns as linear combination of factors:
        E[R] = β1*F1 + β2*F2 + ... + βn*Fn
    
    Can be used for:
    - Custom factor models
    - Factor combinations
    - Simple linear strategies
    """
    
    def __init__(self, model_type="linear_factor", config=None):
        """
        Args:
            config:
                - factors: List of factor names
                - weights: Optional fixed weights (if not training)
                - regularization: 'none', 'ridge', 'lasso'
                - alpha: Regularization strength
        """
        pass
    
    def fit(self, X, y):
        """
        Learn factor weights via linear regression.
        
        Args:
            X: Factor values (columns = factors)
            y: Forward returns
        """
        # Use sklearn LinearRegression, Ridge, or Lasso
        pass
    
    def predict(self, X):
        """
        Predict expected returns from factor exposures.
        
        Returns:
            Expected returns = factors @ weights
        """
        pass
```

**Features Expected:**
- Arbitrary set of factors defined in config

---

### 4. MLModels (RandomForest, XGBoost, etc.)
**Files:** `random_forest_model.py`, `xgboost_model.py`, etc.  
**Status:** ⚠️ CHECK IF EXIST  
**Used By:** MLStrategy

**Description:**
Complex ML models for nonlinear relationships.

**Expected Interface:**
All should inherit from `BaseModel` and implement:
```python
def fit(self, X, y):
    """Train the ML model"""
    pass

def predict(self, X):
    """Predict expected returns"""
    pass
```

**Features Expected:**
- Full set of technical features
- Momentum, volatility, technical indicators, volume, etc.

**Action:** Check `models/implementations/` directory for existing ML models

---

## 📋 Implementation Priority

### High Priority (Required for Current Strategies)
1. ✅ FF5RegressionModel - Already exists
2. 🔨 MomentumRankingModel - Required for DualMomentumStrategy

### Medium Priority
3. 🔨 LinearFactorModel - Nice to have for extensibility

### Low Priority (Depends on Existing Implementations)
4. ⚠️ ML Models - Check what already exists

---

## 🎯 Model Requirements Checklist

All models must:
- [ ] Inherit from `BaseModel`
- [ ] Implement `fit(X, y)` method
- [ ] Implement `predict(X)` method  
- [ ] Accept `config` dict in `__init__`
- [ ] Return predictions as numpy array or pandas Series
- [ ] Handle edge cases (empty data, NaN values, etc.)
- [ ] Include logging
- [ ] Be serializable (for model registry)

---

## 📝 Notes for Implementers

### For Momentum Model
- Start with rule-based implementation (simpler)
- Add trainable mode later if needed
- Key logic: Rank by momentum, filter positive, select top N
- Can be as simple as a ranking + threshold function

### For Factor Models
- FF5Model can serve as template
- Main difference: factor set and weights
- Consider using sklearn's LinearRegression as base

### For ML Models
- Check what's already in `models/implementations/`
- May already have RandomForest, XGBoost, etc.
- Ensure they follow BaseModel interface
- Ensure they work with FeatureEngineeringPipeline output

---

## 🔗 Related Files

- `models/base/base_model.py` - Base class definition
- `models/base/model_factory.py` - Model registration
- `models/serving/predictor.py` - Production serving
- `strategies/unified_base_strategy.py` - New unified strategy base

---

## ✅ Completion Criteria

This TODO can be closed when:
1. ✅ FF5Model confirmed working
2. ✅ MomentumRankingModel implemented and tested
3. ⚠️ ML models checked/implemented as needed
4. ✅ All models registered in ModelFactory
5. ✅ All models work with FeatureEngineeringPipeline
6. ✅ All models work with ModelPredictor
7. ✅ Integration tests pass for all strategies

